#!/bin/sh
cp Makefile Makefile.sw
cp lib/Makefile lib/Makefile.sw
cp tests/Makefile tests/Makefile.sw
cp utilities/Makefile utilities/Makefile.sw
