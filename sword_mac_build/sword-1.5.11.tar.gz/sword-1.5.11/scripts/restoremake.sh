#!/bin/sh
cp Makefile.sw Makefile
cp lib/Makefile.sw lib/Makefile
cp tests/Makefile.sw tests/Makefile
cp utilities/Makefile.sw utilities/Makefile
