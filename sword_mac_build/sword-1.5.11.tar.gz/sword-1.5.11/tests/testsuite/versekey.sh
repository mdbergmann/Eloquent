#!/bin/sh

../versekeytest
